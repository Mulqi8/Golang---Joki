# Notes Contrib
Feel free to upload your files to this repositories :)
- [putra1](https://github.com/SaputraZulfi1404)
- [adan](https://github.com/adan2911)
